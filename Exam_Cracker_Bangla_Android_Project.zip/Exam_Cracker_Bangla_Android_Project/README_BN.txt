EXAM CRACKER BANGLA — Android APK Build Project

এই প্রজেক্টে আপনার দেওয়া Exam_Cracker_Bangla_Export_Fixed.html ফাইলটি
app/src/main/assets/index.html হিসেবে অপরিবর্তিত রাখা হয়েছে। অ্যাপটি স্থানীয়
HTML ফাইল থেকে চালু হবে, তাই মূল পেজ খোলার জন্য ইন্টারনেট লাগবে না।

মোবাইল দিয়ে APK তৈরির ধাপ:
1. GitHub-এ একটি নতুন repository তৈরি করুন।
2. এই ZIP-এর ভেতরের সব ফাইল ও ফোল্ডার repository-তে upload করুন।
   ZIP ফাইলটিকে repository-তে শুধু ZIP হিসেবে রাখবেন না—ভেতরের ফাইলগুলো upload করুন।
3. GitHub repository-র Actions tab খুলুন।
4. "Build Exam Cracker Bangla APK" workflow নির্বাচন করুন।
5. "Run workflow" চাপুন এবং build শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
6. সফল হলে workflow run-এর নিচে Artifacts থেকে
   "Exam-Cracker-Bangla-debug-APK" ডাউনলোড করুন।
7. ZIP artifact extract করে app-debug.apk ইনস্টল করুন।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি পরীক্ষামূলক debug APK build project; release signing করা নেই।
- HTML-এর মূল ডেটা/প্রশ্ন/নোট ফাইলটি হুবহু অন্তর্ভুক্ত, কিন্তু APK-তে
  আমদানি/রপ্তানি, ডাউনলোড, ব্যাকআপ, ফাইল-পিকার এবং ডিভাইস-ভিত্তিক আচরণ
  Chrome-এর মতোই কাজ করবে—এটি বাস্তব Android ডিভাইসে পরীক্ষা করতে হবে।
- HTML-এর localStorage ডেটা Chrome থেকে APK-তে স্বয়ংক্রিয়ভাবে যাবে না।
  Chrome-এর পুরোনো ডেটা থাকলে অ্যাপের নিজস্ব backup/export-import পদ্ধতি
  দিয়ে আলাদাভাবে স্থানান্তর করতে হবে।
- কোনো APK install করার আগে উৎস repository ও build artifact যাচাই করুন।
